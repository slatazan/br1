# jitter-free-pixelart-scaling
Jitter-free Pixel Art Scaling in Godot Engine

This project uses work from Akorian and Ansimuz. Here are the links to credit them.

Work by Akorian: https://github.com/CptPotato/GodotThings

GothicVania Town by Ansimuz: https://opengameart.org/content/gothicvania-town


void fragment() {
	vec4 Texture = texturePointSmooth(TEXTURE, UV);
	Texture.a = 0.5; // test
	COLOR = Texture.rgba;
}

