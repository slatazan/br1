0 // uniq // выдают в runtime.
133 // nom_base // номер из названия этого файла. z_u1_kont_envier
type_unit // type
0 // active
0 // auto_start
0 // active_b
0 // event_q
0 // wait_full
0 // wait_now
0 // wait_cd_full
0 // wait_cd_now
0 // trig_off_after_wait
0 // nx
0 // n1
0 // n2
0 // n3
0 // bank_now # stak_now, для юнита на поле боя
0 // bank_max
0 // bank_ext # stak_start, для юнита на поле боя
0 // radius
0 // test_hit_points
0 // game_easy_obj // 0 или 1
0 // baner
klan_kont // klan
0 // bind1
0 // stak_alone
5 // stak_one_or_minimal
0 // eq_to
0 // eq_to_ext
0 // use_in_war
0 // use_hero_rang
0 // use_tal_index
0 // use_tal_need_lvl
0 // gold_sell
50 // gold_shop // сколько платим за наём // и процент за выстрел
0 // res_wood
0 // res_rood
0 // res_sol
0 // res_sah
0 // res_ser
0 // res_gas
1 // level_now
14 // level_exp_now // сила юнита - даём подарок опыта за этот юнит.
0 // level_exp_next
0 // spec_or_dead
0 // kle1
0 // kle2
0 // kle3
0 // steps_now
3 // steps_max
0 // steps_ext
0 // hp_top // для динамики
16 // hp_unit
0 // hp_unit_start // для динамики
2 // dmg_min
4 // dmg_max
dmg_mode__norma // dmg_mode // можно ноль оставлять, если _норма.
10 // rate_dist
10 // rate_dist_sh
0 // rate_dist_ext
6 // rate_hand
6 // rate_hand_sh
0 // rate_hand_ext
10 // anti_dist
10 // anti_dist_sh
0 // anti_dist_ext
10 // anti_hand
10 // anti_hand_sh
0 // anti_hand_ext
0 // anti_mag
0 // anti_mag_sh
0 // anti_mag_ext
0 // ignor_bon
0 // ignor_neg
4 // ini
4 // ini_sh
0 // ini_ext
0 // luck
0 // moral
0 // moral_good_event
0 // moral_bad_event
0 // mana // ab__need_mana
0 // mana_full
8 // bolt // ab__need_bolt
8 // bolt_full
1 // atk_q // подразумевает CONST _макс // большэ двух нельзя.
0 // atk_back_q // динамичное свойство
1 // atk_back_q_max // обычно, 1 ответка
0 // atk_suport
0 // atk_long_hand
z_basis_blood // basis1
0 // basis2
0 // basis2_perc // ноль или проценты
0 // vis_name_index
0 // vis_bank
0 // vis_inst
0 // ab__dekor
0 // ab__is_minor
0 // ab__need_steps_for_use
0 // ab__need_ray_targ
0 // ab__targ_vers // targ_vers__self
0 // ab__dist_min
0 // ab__dist_min_err_perc // 50, как 0.5
5 // ab__dist_max // для стандартной даль-атаки
50 // ab__dist_max_err_perc // делим на 2, если превышаем даль 5.
0 // ab__area_type
0 // ab__area_tiles
0 // ef_prior
0 // ef_part
0 // ef_blocked_by_ef
0 // ef_replace_ef
0 // ef_0_from_clearing
0 // ef_0_from_damage
0 // ef_0_from_starting_mask
0 // ef_0_from_unit_death
0 // ef__evt_on_start // запоминать war_unit.стартовое_место_в_лодке
0 // ef__evt_on_reset
0 // ef__evt_on_end
12 // ef_starting_layers // оригинальный недельный прирост
0 // ef_layers_pack_add
0 // ef_tik_type
0 // ef_tik_rate
0 // ef_tik_klv
0 // ef_tik_skip1
0 // ef_tik_progres
0 // ef_tik_layer_mult
0 // zap1
0 // zap2
0 // zap3
0 // zap4
0 // zap5
z_ef_envier_hat_hater // m2_stabil [ 1].x
1 //  m2_stabil [ 1].y
0 // 2.x
0 //  2.y
0 // 3.x
0 //  3.y
0 // 4.x
0 //  4.y
0 // 5.x
0 //  5.y
0 // 6.x
0 //  6.y
0 // 7.x
0 //  7.y
0 // 8.x
0 //  8.y
0 // 9.x
0 //  9.y
0 // 10.x
0 //  10.y
завистник

// --- любые наброски (текстовые) складываем в конце файла..

Пусть человеческие юниты клана обязаны иметь минимал-стак, аля 3 или 5.
Мелкие по 5 (или 6), а крупные - по три (или 4).


-+-+-+-+-[ромбик-1] завистник (1-й уровень).. // название юнита.
{

_шапко_закидательство // стабильная пасивка-бонус..
Урон дальней атаки будет удвоен, если целевой стак меньшэ, вдвое.

// Если( юнит.колво_в_стаке / дальния_цель.колво_в_стаке > 2.0 )
// тогда юнит.спец_множ = 2.0;
// иначе юнит.спец_множ = 1.0;

_кровный // условный базис.

tо* 6, 6 // норма, тень // слабей в руко-пашке, чем в дальней атаке.
^о* 10, 10 // камни кидают, золотые - выстрелы платные.

%tо* 10, 10 // стандарт для мелких.
%^о* 10, 10

у 2 и 4 // удвоено - сам юнит, как сдвоеный пулемёт.
х 16 // удвоено // прирост 12 в псевдо-неделю (доп-прироста нет).
ш 3 // мало шагов, но это не влияет на движуху лодки отряда.
и 4 // средния инициатива участия в раунде.
м 0/0 // нет маны.
8 выстрелов.
цена юнита 50 золота // 3 процента = 1.5 золотых за выстрел.
опыт 14. // условная _значимость этого юнита. (кач капитанов)

}



