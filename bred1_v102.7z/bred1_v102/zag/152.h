0 // uniq // выдают в runtime.
152 // nom_base // номер из названия этого файла. z_u4_myst_ghosts
type_unit // type
0 // active
0 // auto_start
0 // active_b
0 // event_q
0 // wait_full
0 // wait_now
0 // wait_cd_full
0 // wait_cd_now
0 // trig_off_after_wait
0 // nx
0 // n1
0 // n2
0 // n3
0 // bank_now // stak_now
0 // bank_max
0 // bank_ext
0 // radius
0 // test_hit_points
0 // game_easy_obj // 0 или 1
0 // baner
klan_myst // klan
0 // bind1
0 // stak_alone
13 // stak_one_or_minimal
0 // eq_to
0 // eq_to_ext
0 // use_in_war
0 // use_hero_rang
0 // use_tal_index
0 // use_tal_need_lvl
0 // gold_sell
200 // gold_shop // сколько платим за наём
0 // res_wood
0 // res_rood
0 // res_sol
0 // res_sah
0 // res_ser
0 // res_gas
2 // level_now
66 // level_exp_now // сила юнита - даём подарок опыта за этот юнит.
0 // level_exp_next
0 // spec_or_dead
0 // kle1
0 // kle2
0 // kle3
0 // steps_now
5 // steps_max
0 // steps_ext
0 // hp_top // для динамики
43 // hp_unit
0 // hp_unit_start // для динамики
4 // dmg_min
6 // dmg_max
dmg_mode__norma // dmg_mode // можно ноль оставлять, если _норма.
8 // rate_dist
8 // rate_dist_sh
0 // rate_dist_ext
13 // rate_hand
13 // rate_hand_sh
0 // rate_hand_ext
33 // anti_dist
33 // anti_dist_sh
0 // anti_dist_ext
30 // anti_hand
30 // anti_hand_sh
0 // anti_hand_ext
0 // anti_mag
0 // anti_mag_sh
0 // anti_mag_ext
0 // ignor_bon
0 // ignor_neg
4 // ini
4 // ini_sh
0 // ini_ext
0 // luck
0 // moral // игнор из-за элементаль-базиса.
0 // moral_good_event
0 // moral_bad_event
0 // mana // ab__need_mana
0 // mana_full
2 // bolt // ab__need_bolt
2 // bolt_full
1 // atk_q // подразумевает CONST _макс
0 // atk_back_q // динамичное свойство
1 // atk_back_q_max // обычно, 1 ответка
0 // atk_suport
0 // atk_long_hand
z_basis_air_elem // basis1
z_basis_sun_elem // basis2
50 // basis2_perc // ноль или проценты
0 // vis_name_index
0 // vis_bank
0 // vis_inst
0 // ab__dekor
0 // ab__is_minor
0 // ab__need_steps_for_use
0 // ab__need_ray_targ
0 // ab__targ_vers // targ_vers__self
0 // ab__dist_min
0 // ab__dist_min_err_perc // 50, как 0.5
5 // ab__dist_max
0 // ab__dist_max_err_perc // ноль (нет выстрела), если дальшэ 5 клеток.
0 // ab__area_type
0 // ab__area_tiles
0 // ef_prior
0 // ef_part
0 // ef_blocked_by_ef
0 // ef_replace_ef
0 // ef_0_from_clearing
0 // ef_0_from_damage
0 // ef_0_from_starting_mask
0 // ef_0_from_unit_death
0 // ef__evt_on_start
0 // ef__evt_on_reset
0 // ef__evt_on_end
5 // ef_starting_layers // оригинальный недельный прирост
0 // ef_layers_pack_add
0 // ef_tik_type // unit.alter_dmg_type (указать, если не физич.)
0 // ef_tik_rate
0 // ef_tik_klv
0 // ef_tik_skip1
0 // ef_tik_progres
0 // ef_tik_layer_mult
0 // zap1
0 // zap2
0 // zap3
0 // zap4
0 // zap5
z_ef_el_vigor // m2_stabil [ 1].x
1 //  m2_stabil [ 1].y
z_ef_flight // 2.x
1 //  2.y
z_ab_ghosts_hide // 3.x
1 //  3.y
z_ef_wind_reaction // 4.x
1 //  4.y
0 // 5.x
0 //  5.y
0 // 6.x
0 //  6.y
0 // 7.x
0 //  7.y
0 // 8.x
0 //  8.y
0 // 9.x
0 //  9.y
0 // 10.x
0 //  10.y
призраки


// --- любые наброски (текстовые) складываем в конце файла..



-+-+-+-+-[пика-4] призраки (2-й левел)..
{
_элементаль (? воздух + вода ?) // базис. // ? микс со светом ?
(сначала поставлю воздух + свет)

tо* 13, 13 // 15
^о* 8, 8 // Выдать им пару слабых выстрелов.

%tо* 30, 30
%^о* 33, 33

у 4 и 6 //
х 43 // прирост 5
ш 5 // полёт
и 4
м 0/0
2 выстрела. // было ноль // пусть будет нолём, если дальшэ 5 клеток.
цена юнита 200 //
опыт 66.
ответка 1/1

_электро_бодрость // эл-урон лечит этот юнит.
// заметный хит-бар - танкуем.

Разовая абилка (без маны) _краткая_невидимость на 1 раунд.
// для передышки // возможно, это улетание с места, и нельзя
// ранить _пожаром и подобным уроном по местности.

_реакция_на_ветер // вредный штрих.
Пусть от враждебного Чудо-ветер их сносит по всей линии, до упора.
// либо лиш на одну клетку дальшэ, чем остальных, а то чит будет.

}





