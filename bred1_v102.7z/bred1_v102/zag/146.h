0 // uniq // выдают в runtime.
146 // nom_base // номер из названия этого файла. z_u6_cirk_harlequin
type_unit // type
0 // active
0 // auto_start
0 // active_b
0 // event_q
0 // wait_full
0 // wait_now
0 // wait_cd_full
0 // wait_cd_now
0 // trig_off_after_wait
0 // nx
0 // n1
0 // n2
0 // n3
0 // bank_now // stak_now
0 // bank_max
0 // bank_ext
0 // radius
0 // test_hit_points
0 // game_easy_obj // 0 или 1
0 // baner
klan_cirk // klan
0 // bind1
1 // stak_alone
1 // stak_one_or_minimal
0 // eq_to
0 // eq_to_ext
0 // use_in_war
0 // use_hero_rang
0 // use_tal_index
0 // use_tal_need_lvl
0 // gold_sell
900 // gold_shop // сколько платим за наём
0 // res_wood
0 // res_rood
0 // res_sol
0 // res_sah
0 // res_ser
1 // res_gas
3 // level_now
130 // level_exp_now // сила юнита - даём подарок опыта за этот юнит.
0 // level_exp_next
0 // spec_or_dead
0 // kle1
0 // kle2
0 // kle3
0 // steps_now
5 // steps_max
0 // steps_ext
0 // hp_top // для динамики
96 // hp_unit
0 // hp_unit_start // для динамики
16 // dmg_min
19 // dmg_max
dmg_mode__norma // dmg_mode // можно ноль оставлять, если _норма.
10 // rate_dist
0 // rate_dist_sh
0 // rate_dist_ext
21 // rate_hand
3 // rate_hand_sh
0 // rate_hand_ext
15 // anti_dist
80 // anti_dist_sh
0 // anti_dist_ext
15 // anti_hand
60 // anti_hand_sh
0 // anti_hand_ext
0 // anti_mag
0 // anti_mag_sh
0 // anti_mag_ext
0 // ignor_bon
0 // ignor_neg
5 // ini
5 // ini_sh
0 // ini_ext
0 // luck
units__moral_max // moral
0 // moral_good_event
0 // moral_bad_event
0 // mana // ab__need_mana
0 // mana_full
1 // bolt // ab__need_bolt
1 // bolt_full
1 // atk_q // подразумевает CONST _макс
0 // atk_back_q // динамичное свойство
4 // atk_back_q_max // обычно, 1 ответка
0 // atk_suport
0 // atk_long_hand
z_basis_blood // basis1
z_basis_mechanism // basis2
50 // basis2_perc // ноль или проценты
0 // vis_name_index
0 // vis_bank
0 // vis_inst
0 // ab__dekor
0 // ab__is_minor
0 // ab__need_steps_for_use
0 // ab__need_ray_targ
0 // ab__targ_vers // targ_vers__self
0 // ab__dist_min
0 // ab__dist_min_err_perc // 50, как 0.5
0 // ab__dist_max // пусть без ограничения дальности будет
0 // ab__dist_max_err_perc
0 // ab__area_type
0 // ab__area_tiles
0 // ef_prior
0 // ef_part
0 // ef_blocked_by_ef
0 // ef_replace_ef
0 // ef_0_from_clearing
0 // ef_0_from_damage
0 // ef_0_from_starting_mask
0 // ef_0_from_unit_death
0 // ef__evt_on_start
0 // ef__evt_on_reset
0 // ef__evt_on_end
3 // ef_starting_layers // оригинальный недельный прирост
0 // ef_layers_pack_add
0 // ef_tik_type // unit.alter_dmg_type (указать, если не физич.)
0 // ef_tik_rate
0 // ef_tik_klv
0 // ef_tik_skip1
0 // ef_tik_progres
0 // ef_tik_layer_mult
0 // zap1
0 // zap2
0 // zap3
0 // zap4
0 // zap5
z_ef_link_alter_unit // m2_stabil [ 1].x
z_redir_kle1 //  m2_stabil [ 1].y // виртуал-коробка == 1, гроб == 2
z_ef_wide_sense // 2.x
1 //  2.y
z_ef_otvet__always_crit // 3.x
1 //  3.y
z_ab_wonder_apple // 4.x
1 //  4.y
z_ef_boom6_on_death // 5.x
1 //  5.y
z_ef_anti_fear // 6.x
1 //  6.y
0 // 7.x
0 //  7.y
0 // 8.x
0 //  8.y
0 // 9.x
0 //  9.y
0 // 10.x
0 //  10.y
арлекин


// --- любые наброски (текстовые) складываем в конце файла..

-+-+-+-+-[трилист-6] арлекин (3-й левел)..
{
// юнит с линком на альтэр-юнит - на коробку.
Хотя, пусть все свойства хранит одна анкета.
Особености поведения можно учитывать из сочетания
z_ef_link_alter_unit и учесть доп-число.
Либо только из-за z_u6_cirk_harlequin.
// Я не выделил отдельного номерка под _юнит_коробка,
// но такое можно всегда добавить в конец списка констант.


_кровный, _механизм // базис // жывая кукла, с коробкой на ночь.
// Наверно, мозг + двойная роботическая оболочка (кукла и коробка)

tо* 21, 3 // на свету, и в тени (коробка)
^о* 10, 0

%tо* 15, 80 // дубль у альтэр-юнита // слабая бронь на свету, но
%^о* 15, 80 // в тени, он сидит в шыпастой чудо-коробке.

у 16 и 19 //
х 96 // прирост 4 ? (наверно, 3)
ш 5 // свойство _не_активности_в_тени // лиш контр-удары
и 5
м 0/0
1 выстрел (яблоко). // 27 золотых.
цена юнита 900 // + ртуть-газ-мёд ?
опыт 130.

// ответка 1/1 (у коробки 10/10)
// ... нет альтэр-анкеты == кукла и коробка пусть имеют по 4 ответки.

Всегда критическая ответка (двойной урон).

_восприятие (шырокое восприятие ?)
// Любые шансовые бонусы-негативы 100% примет.
// Например, заклинание Тренировка, ему всегда добавит оба эфекта.


В руках - чудесное зелёное яблоко, которое связано с его абилкой..
Жуй (название абилки можно заменить).
Смысл таков..
Если хватает денег, клоун кусает яблоко, и лечит себя сквозь слои,
кидает огрызок в случийного врага, идёт попытка понизить мораль
жэртве огрызка, на единицу, идёт некий малый урон жэртве, и
всем союзникам клоуна, кроме себя, идёт попытка +1 морали,
сам клоун отнимает себе единицу морали.
// У броска, есть штраф за дальность - всё, как у норм-выстрела.

_единственый_стак // чтобы не было закидывания яблоками.

Формула лечения примерно такая 13 * колво стака клоуна.

И не исключено, что попытка ап-морали каждому союзнику идёт
через шанс, который равен колву стака клоуна.
Тоесть, сжувать яблоко одиночкой = 10% шанс выдать ап-мораль.
(10 арлекинов = 100% поднимут настрой союзников).

Возможно, сам Арлекин всегда имеит макси-мораль, в начале боя,
потому-что она впечатана в его анкету (откуда грузят),
поэтому применение Нормализатора на него - макси-мораль вернуть.

Не исключено, что коробка имеит шанс сюрпризно ответить на удар,
задев всех своих соседей. Либо это по-смертный тригер стака,
не взирая на вид (арлекин или коробка).

z_ef_anti_fear // можно добавить анти-страх

}




