0 // uniq // выдают в runtime.
437 // nom_base // из названия этого файла. z_ae_minor_aroma
type_atk_ef // type
0 // active
0 // auto_start
0 // active_b
0 // event_q
0 // wait_full
0 // wait_now
0 // wait_cd_full
0 // wait_cd_now
0 // trig_off_after_wait
0 // nx
0 // n1
0 // n2
0 // n3
0 // bank_now
0 // bank_max
0 // bank_ext
0 // radius
0 // test_hit_points
0 // game_easy_obj // 0 или 1
0 // baner
0 // klan
0 // bind1
0 // stak_alone
0 // stak_one_or_minimal
0 // eq_to
0 // eq_to_ext
0 // use_in_war
0 // use_hero_rang
0 // use_tal_index
0 // use_tal_need_lvl
0 // gold_sell
0 // gold_shop
0 // res_wood
0 // res_rood
0 // res_sol
0 // res_sah
0 // res_ser
0 // res_gas
0 // level_now
0 // level_exp_now
0 // level_exp_next
0 // spec_or_dead
0 // kle1
0 // kle2
0 // kle3
0 // steps_now
0 // steps_max
0 // steps_ext
0 // hp_top
0 // hp_unit
0 // hp_unit_start
0 // dmg_min
0 // dmg_max
0 // dmg_mode
0 // rate_dist
0 // rate_dist_sh
0 // rate_dist_ext
0 // rate_hand
0 // rate_hand_sh
0 // rate_hand_ext
0 // anti_dist
0 // anti_dist_sh
0 // anti_dist_ext
0 // anti_hand
0 // anti_hand_sh
0 // anti_hand_ext
0 // anti_mag
0 // anti_mag_sh
0 // anti_mag_ext
0 // ignor_bon
0 // ignor_neg
0 // ini
0 // ini_sh
0 // ini_ext
0 // luck
0 // moral
0 // moral_good_event
0 // moral_bad_event
0 // mana // ab__need_mana
0 // mana_full
0 // bolt // ab__need_bolt
0 // bolt_full
0 // atk_q
0 // atk_back_q
0 // atk_back_q_max
0 // atk_suport
0 // atk_long_hand
0 // basis1
0 // basis2
0 // basis2_perc // ноль или проценты
0 // vis_name_index
0 // vis_bank
0 // vis_inst
0 // ab__dekor
0 // ab__is_minor
0 // ab__need_steps_for_use
0 // ab__need_ray_targ
0 // ab__targ_vers // targ_vers__self
0 // ab__dist_min
0 // ab__dist_min_err_perc // 50, как 0.5
0 // ab__dist_max
0 // ab__dist_max_err_perc
0 // ab__area_type
0 // ab__area_tiles
0 // ef_prior
0 // ef_part
0 // ef_blocked_by_ef
0 // ef_replace_ef
0 // ef_0_from_clearing
0 // ef_0_from_damage
0 // ef_0_from_starting_mask
0 // ef_0_from_unit_death
0 // ef__evt_on_start
0 // ef__evt_on_reset
0 // ef__evt_on_end
0 // ef_starting_layers
0 // ef_layers_pack_add
0 // ef_tik_type
0 // ef_tik_rate
0 // ef_tik_klv
0 // ef_tik_skip1
0 // ef_tik_progres
0 // ef_tik_layer_mult
0 // zap1
0 // zap2
0 // zap3
0 // zap4
0 // zap5
0 // m2_stabil [ 1].x
0 //  m2_stabil [ 1].y
0 // 2.x
0 //  2.y
0 // 3.x
0 //  3.y
0 // 4.x
0 //  4.y
0 // 5.x
0 //  5.y
0 // 6.x
0 //  6.y
0 // 7.x
0 //  7.y
0 // 8.x
0 //  8.y
0 // 9.x
0 //  9.y
0 // 10.x
0 //  10.y
пудра феи

// --- любые наброски (текстовые) складываем в конце файла..

//  фея. _ароматная_пудра (Минорный).





