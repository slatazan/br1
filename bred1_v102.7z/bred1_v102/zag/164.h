0 // uniq // выдают в runtime.
164 // nom_base // из названия этого файла. z_u8_flam_queen_jatva
type_unit // type
0 // active
0 // auto_start
0 // active_b
0 // event_q
0 // wait_full
0 // wait_now
0 // wait_cd_full
0 // wait_cd_now
0 // trig_off_after_wait
0 // nx
0 // n1
0 // n2
0 // n3
0 // bank_now // stak_now
0 // bank_max
0 // bank_ext
0 // radius
0 // test_hit_points
0 // game_easy_obj // 0 или 1
0 // baner
klan_flam // klan
0 // bind1
1 // stak_alone
0 // stak_one_or_minimal // ???? единицу сюда поставить ?
0 // eq_to
0 // eq_to_ext
0 // use_in_war
0 // use_hero_rang
0 // use_tal_index
0 // use_tal_need_lvl
0 // gold_sell
7000 // gold_shop // сколько платим за наём
0 // res_wood
0 // res_rood
4 // res_sol
0 // res_sah
0 // res_ser
1 // res_gas
4 // level_now
1500 // level_exp_now // сила юнита - даём подарок опыта за этот юнит.
0 // level_exp_next
0 // spec_or_dead
0 // kle1
0 // kle2
0 // kle3
0 // steps_now
2 // steps_max
0 // steps_ext
0 // hp_top // для динамики
520 // hp_unit
0 // hp_unit_start // для динамики
25 // dmg_min
40 // dmg_max
dmg_mode__norma // dmg_mode // можно ноль оставлять, если _норма.
10 // rate_dist
10 // rate_dist_sh
0 // rate_dist_ext
5 // rate_hand
5 // rate_hand_sh
0 // rate_hand_ext
25 // anti_dist
25 // anti_dist_sh
0 // anti_dist_ext
25 // anti_hand
25 // anti_hand_sh
0 // anti_hand_ext
10 // anti_mag
10 // anti_mag_sh
0 // anti_mag_ext
0 // ignor_bon
1 // ignor_neg
7 // ini
7 // ini_sh
0 // ini_ext
0 // luck
0 // moral
0 // moral_good_event
0 // moral_bad_event
30 // mana // ab__need_mana
30 // mana_full
0 // bolt // ab__need_bolt
0 // bolt_full
1 // atk_q // подразумевает CONST _макс
0 // atk_back_q // динамичное свойство
1 // atk_back_q_max // обычно, 1 ответка
0 // atk_suport
-1 // atk_long_hand // z_ab_harvester
z_basis_mechanism // basis1
z_basis_elite // basis2
50 // basis2_perc // ноль или проценты
0 // vis_name_index
0 // vis_bank
0 // vis_inst
0 // ab__dekor
0 // ab__is_minor
0 // ab__need_steps_for_use
0 // ab__need_ray_targ
0 // ab__targ_vers // targ_vers__self
0 // ab__dist_min
0 // ab__dist_min_err_perc // 50, как 0.5
0 // ab__dist_max
0 // ab__dist_max_err_perc
1 // ab__area_type // z_ef_atk_none_otvet
0 // ab__area_tiles
0 // ef_prior
0 // ef_part
0 // ef_blocked_by_ef
0 // ef_replace_ef
0 // ef_0_from_clearing
0 // ef_0_from_damage
0 // ef_0_from_starting_mask
0 // ef_0_from_unit_death
0 // ef__evt_on_start
0 // ef__evt_on_reset
0 // ef__evt_on_end
1 // ef_starting_layers // оригинальный недельный прирост
0 // ef_layers_pack_add
0 // ef_tik_type // unit.alter_dmg_type (указать, если не физич.)
0 // ef_tik_rate
0 // ef_tik_klv
0 // ef_tik_skip1
0 // ef_tik_progres
0 // ef_tik_layer_mult
0 // zap1
0 // zap2
0 // zap3
0 // zap4
0 // zap5
z_ab_harvester // m2_stabil [ 1].x
1 //  m2_stabil [ 1].y
z_ef_otvet__el_ring_any // 2.x
1 //  2.y
z_sp_cirk_regeneration // 3.x
1 //  3.y
z_ab_red_snow // 4.x
1 //  4.y
z_ef_gifts_for_queen // 5.x
1 //  5.y
z_ef_ignor_neg // 6.x
1 //  6.y
z_ef_atk_none_hand // 7.x
1 //  7.y
z_ef_atk_none_otvet // 8.x
1 //  8.y
0 // 9.x
0 //  9.y
0 // 10.x
0 //  10.y
королева-жатва


// --- любые наброски (текстовые) складываем в конце файла..

-+-+-+-+-[сердце-8] королева-жатва (4-й левел)..
{
_механизм, _элита // базис // золотая статуя богини.

tо* 5, 5 // для ответки
^о* 10, 10 // для абилки _жатва.

%tо* 25, 25
%^о* 25, 25

у 25 и 40 // ответка, и опора для _жатвы.
х 520 // прирост 1.
ш 2 // _жатву можно применить с места, или сделав один шаг.
и 7
м 30/30
0 выстрелов. // даль-атака есть, но выстрелы не используем.
цена юнита 7000 // +5 гемов ?
опыт 1500.
ответка 1/1

_эл_контр_удар_всех_соседей // электро-ответка.

_нет_стандартной_ближней_атаки.

_жатва (10 маны, 2 раунда откат) (иметь 1 шаг на момент применения).
Вертушки-лезвия улетают в 6 сторон, до первого встречного.
Это считаем физ-уроном, и даль-атакой, без учёта дальности.

Выдать ей заклинание Регенератор // на себя ей нельзя - лечить слуг.

? абилка Красный снег ? // придумать некое проклятие на всё поле.
Какой-нить демонический снег пробует повесить негативы на всех.
Но возможно, что для Демонического стража это будет полезно.

_игнор_негатива // блокирование плохих заклятий от кастеров.
А некие спец-события могут внедрить негативы.

_единственый_стак.

_подарки_для_королевы
Каждая единица этого юнита, которую найдут во владениях игрока
(в запасе, в городе, в отряде), отнимает 100 золота в сутки.
Допустим, что это свойство (подарки) блокирует увольнение юнита.

}



