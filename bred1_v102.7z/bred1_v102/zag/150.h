0 // uniq // выдают в runtime.
150 // nom_base // номер из названия этого файла. z_u2_myst_skull_flicker
type_unit // type
0 // active
0 // auto_start
0 // active_b
0 // event_q
0 // wait_full
0 // wait_now
0 // wait_cd_full
0 // wait_cd_now
0 // trig_off_after_wait
0 // nx
0 // n1
0 // n2
0 // n3
0 // bank_now // stak_now
0 // bank_max
0 // bank_ext
0 // radius
0 // test_hit_points
0 // game_easy_obj // 0 или 1
0 // baner
klan_myst // klan
0 // bind1
1 // stak_alone // здесь 1 == уникальный стак на поле боя.
0 // stak_one_or_minimal // здесь 1 == зажатый псевдо-стак, аля капитан.
0 // eq_to
0 // eq_to_ext
0 // use_in_war
0 // use_hero_rang
0 // use_tal_index
0 // use_tal_need_lvl
0 // gold_sell
50 // gold_shop // сколько платим за наём
1 // res_wood
1 // res_rood
0 // res_sol
0 // res_sah
0 // res_ser
0 // res_gas
1 // level_now
10 // level_exp_now // сила юнита - даём подарок опыта за этот юнит.
0 // level_exp_next
0 // spec_or_dead
0 // kle1
0 // kle2
0 // kle3
0 // steps_now
3 // steps_max
0 // steps_ext
0 // hp_top // для динамики
44 // hp_unit
0 // hp_unit_start // для динамики
0 // dmg_min
1 // dmg_max
dmg_mode__norma // dmg_mode // можно ноль оставлять, если _норма.
0 // rate_dist
0 // rate_dist_sh
0 // rate_dist_ext
10 // rate_hand
10 // rate_hand_sh
0 // rate_hand_ext
10 // anti_dist
10 // anti_dist_sh
0 // anti_dist_ext
10 // anti_hand
10 // anti_hand_sh
0 // anti_hand_ext
10 // anti_mag
10 // anti_mag_sh
0 // anti_mag_ext
0 // ignor_bon
0 // ignor_neg
2 // ini
2 // ini_sh
0 // ini_ext
0 // luck
0 // moral
0 // moral_good_event
0 // moral_bad_event
0 // mana // ab__need_mana
20 // mana_full
0 // bolt // ab__need_bolt
0 // bolt_full
1 // atk_q // подразумевает CONST _макс
0 // atk_back_q // динамичное свойство
0 // atk_back_q_max // обычно, 1 ответка
0 // atk_suport
0 // atk_long_hand
z_basis_mechanism // basis1
z_basis_fire_elem // basis2
50 // basis2_perc // ноль или проценты
0 // vis_name_index
0 // vis_bank
0 // vis_inst
0 // ab__dekor
0 // ab__is_minor
0 // ab__need_steps_for_use
0 // ab__need_ray_targ
0 // ab__targ_vers // targ_vers__self
0 // ab__dist_min
0 // ab__dist_min_err_perc // 50, как 0.5
0 // ab__dist_max
0 // ab__dist_max_err_perc
0 // ab__area_type
0 // ab__area_tiles
0 // ef_prior
0 // ef_part
0 // ef_blocked_by_ef
0 // ef_replace_ef
0 // ef_0_from_clearing
0 // ef_0_from_damage
0 // ef_0_from_starting_mask
0 // ef_0_from_unit_death
0 // ef__evt_on_start
0 // ef__evt_on_reset
0 // ef__evt_on_end
1 // ef_starting_layers // оригинальный недельный прирост
0 // ef_layers_pack_add
0 // ef_tik_type // unit.alter_dmg_type (указать, если не физич.)
0 // ef_tik_rate
0 // ef_tik_klv
0 // ef_tik_skip1
0 // ef_tik_progres
0 // ef_tik_layer_mult
0 // zap1
0 // zap2
0 // zap3
0 // zap4
0 // zap5
z_ef_terrible_aura6 // m2_stabil [ 1].x
1 //  m2_stabil [ 1].y
z_ab_skull_mana_drain // 2.x
7 //  2.y
z_ef_flight // 3.x
1 //  3.y
z_ef_invisible_observer // 4.x
1 //  4.y
z_ef_not_a_picker // 5.x
1 //  5.y
z_ef_ignor_morale // 6.x
1 //  6.y
0 // 7.x
0 //  7.y
0 // 8.x
0 //  8.y
0 // 9.x
0 //  9.y
0 // 10.x
0 //  10.y
череп-мерцатель


// --- любые наброски (текстовые) складываем в конце файла..

-+-+-+-+-[пика-2] череп-мерцатель (1-й уровень)..
{
// оригинальный мистический юнит.
(есть его пиратский повтор на этом-жэ месте, в клане Пламя)

_механизм, _элементаль_какой_то // базис.

tо* 10, 10
^о* 0, 0

%tо* 10, 10
%^о* 10, 10

у 0 и 1 // промах или минимальный удар.
х 44 // крупный хит-бар, среди 1-го уровня.
ш 3  // мало, но полёт.
и 2  // 1 или 2 сюда
м 0/20 // набираем помаленьку.
0 выстрелов.
цена юнита 50 + 1 дерево // руда
опыт 10.
ответка 0/0

Допустим, что Перевязка его не лечит (из-за элементаль-порции).

_воровство_маны (абилка без маны, раунд пере-зарядка, линия взгляда).
Но не отдавать капитанам, а складывать у себя - пусть сами заберут.
// Сколько маны отнимает череп за один раз - 7 (или сколько было).

_единственый // чтобы игроки не размножали воров маны.

_летает.

_аура_ужасного_соседа.
Любой сосед, который совершает атаку (и по черепу тож),
будучи на соседней клетке - шансово повергается в ужас,
и атаку не совершает - вместо этого бежыт 1 или 2 клетки от черепа.

Контрастная атака - ноль (само-промах) или единица.
Если проклят, то всегда промах.
А если удар сработал-попал, то шанс срабатывания авто-эфекта,
который проваливает мораль, или ешё что-нить сюда потом подставить.


_невидимый_наблюдатель // разведка невидимая врагам и нейтралам этапа.
На схеме этапа, он (один в лодке) невидимый, и не мешает движэнию,
и не стартует переход на поле боя ... если на нём остановились.
// Технически, лодку одинокого черепа поместили на _борт_этапа, но
// рисуют на нужной клетке, и видимость добавляют с нужного места.

_не_собиратель // нельзя подбирать предметы.

Он сам не пролезет на клетки, где занято, но соседнии клетки,
рядом с монстрами, доступны.

}





