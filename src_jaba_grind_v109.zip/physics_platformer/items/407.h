0 // uniq // выдают в runtime.
407 // nom_base // из названия этого файла.
1 // type
0 // event_q
0.0 // wait_full_f
0.0 // wait_now_f
0.0 // radius_f
0 // nx
0 // n1
0 // n2
0 // n3
0 // n4
0 // n5
0 // bank_now
0 // bank_max
0 // bank_ext
0 // game_easy_obj
0 // baner
0 // klan
0 // bind1
0 // stak_alone
0 // kill_on_use
0 // eq_to
0 // eq_to_ext
0 // use_in_war
0 // use_hero_rang
0 // use_tal_index
0 // use_tal_need_lvl
0 // fame_need
0 // fame_index
0 // gold_sell
0 // gold_shop
0 // res_wood
0 // res_rood
0 // res_sol
0 // res_sah
0 // res_ser
0 // res_gas
0 // level_now
0 // level_max
0 // level_exp_now
0 // level_exp_next
0 // spec_or_dead
0 // hp_top
0 // hp_unit
0 // hp_unit_start
0 // dmg_min
0 // dmg_max
0 // dmg_mode
0 // rate_dist
0 // rate_hand
0 // anti_mag
0 // ignor_bon
0 // ignor_neg
0 // mana
0 // mana_full
0 // bolt
0 // bolt_full
0 // basis1
0 // basis2
0.0 // basis2_perc_f01
0 // ab__is_minor
0 // ab__need_ray_targ
0 // ab__targ_vers
0 // ab__dist_min
0.0 // ab__dist_min_err_f01
0 // ab__dist_max
0.0 // ab__dist_max_err_f01
0 // ab__area_type
0 // ab__area_tiles
0 // ef_prior
0 // ef_part
0 // ef_blocked_by_ef
0 // ef_replace_ef
0 // ef_0_from_clearing
0 // ef_0_from_damage
0 // ef_0_from_starting_mask
0 // ef_0_from_unit_death
0 // ef__evt_on_start
0 // ef__evt_on_reset
0 // ef__evt_on_end
0 // ef_starting_layers
0 // ef_layers_pack_add
0 // ef_tik_type
0 // ef_tik_rate
0 // ef_tik_klv
0 // ef_tik_skip1
0 // ef_tik_progres
0 // ef_tik_layer_mult
0 // zap1
0 // zap2
0 // zap3
0 // zap4
0 // zap5
0 // zap6
0 // zap7
0 // zap8
0 // zap9

str_name  три стринга забираем из отдельного файла папки локализаций
str_hint 
str_icon 

// --- любые наброски (текстовые) складываем в конце файла..



